package com.gemastik.android.mexia.ui.drawer.kontak

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gemastik.android.mexia.R

class KontakActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kontak)
    }
}