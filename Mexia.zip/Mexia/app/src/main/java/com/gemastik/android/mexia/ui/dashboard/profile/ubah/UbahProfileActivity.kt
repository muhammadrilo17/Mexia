package com.gemastik.android.mexia.ui.dashboard.profile.ubah

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gemastik.android.mexia.R

class UbahProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ubah_profile)
    }
}