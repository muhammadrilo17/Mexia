package com.gemastik.android.mexia.ui.login.forgetkey

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gemastik.android.mexia.R

class ForgetPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)
    }
}