package com.gemastik.android.mexia.ui.dashboard.home.pengenalanhuruf

object DummyAlphabet {

    fun generateAlphabet(): List<AlphabetEntity> {
        val data = ArrayList<AlphabetEntity>()
        data.add(
            AlphabetEntity("1", "A", "3")
        )
        data.add(
            AlphabetEntity("2", "B", "3")
        )
        data.add(
            AlphabetEntity("3", "C", "3")
        )
        data.add(
            AlphabetEntity("4", "D", "3")
        )
        data.add(
            AlphabetEntity("5", "E", "3")
        )
        data.add(
            AlphabetEntity("6", "F", "3")
        )
        data.add(
            AlphabetEntity("7", "G", "3")
        )
        data.add(
            AlphabetEntity("8", "H", "3")
        )
        data.add(
            AlphabetEntity("9", "I", "3")
        )
        data.add(
            AlphabetEntity("10", "J", "3")
        )
        data.add(
            AlphabetEntity("11", "K", "3")
        )
        data.add(
            AlphabetEntity("12", "L", "3")
        )
        data.add(
            AlphabetEntity("13", "M", "3")
        )
        data.add(
            AlphabetEntity("14", "N", "3")
        )
        data.add(
            AlphabetEntity("15", "O", "3")
        )
        data.add(
            AlphabetEntity("16", "P", "3")
        )
        data.add(
            AlphabetEntity("17", "Q", "3")
        )
        data.add(
            AlphabetEntity("18", "R", "3")
        )
        data.add(
            AlphabetEntity("19", "S", "3")
        )
        data.add(
            AlphabetEntity("20", "T", "3")
        )
        data.add(
            AlphabetEntity("21", "U", "3")
        )
        data.add(
            AlphabetEntity("22", "V", "3")
        )
        data.add(
            AlphabetEntity("23", "W", "3")
        )
        data.add(
            AlphabetEntity("24", "X", "3")
        )
        data.add(
            AlphabetEntity("25", "Y", "3")
        )
        data.add(
            AlphabetEntity("26", "Z", "3")
        )

        return data
    }
}