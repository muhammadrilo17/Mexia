package com.gemastik.android.mexia.repository.remote.entity

class ApiUserEntity (
    var id: String = "",
    var username: String = "",
    var email: String = "",
    var password: String = "",
    var phoneNumber: String = "",
    var address: String = "kalimantan",
    var timeLearning: String = "",
    var totalXp: String = "",
    var pathImage: String = ""
)