package com.gemastik.android.mexia.repository.remote.entity

class Api5WordEntity (
    var id : String = "",
    var name : String = "",
    var image : String = "",
    var point : String = ""
)