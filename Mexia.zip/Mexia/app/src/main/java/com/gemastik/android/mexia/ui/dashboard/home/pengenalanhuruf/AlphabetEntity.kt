package com.gemastik.android.mexia.ui.dashboard.home.pengenalanhuruf

class AlphabetEntity(
    var id : String = "",
    var alphabet: String = "",
    var xp : String = ""
)